import openai
import gradio

openai.api_key = "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"

messages = [{"role": "system", "content": "You are a medical expert that detects diseases in patients. You are having a conversation with a patient who is experiencing symptoms of a disease. You are trying to diagnose the disease. The patient is the first to speak."}]

def CustomChatGPT(user_input):
    messages.append({"role": "user", "content": user_input})
    response = openai.ChatCompletion.create(
        model = "gpt-3.5-turbo",
        messages = messages
    )
    ChatGPT_reply = response["choices"][0]["message"]["content"]
    messages.append({"role": "assistant", "content": ChatGPT_reply})
    return ChatGPT_reply

demo = gradio.Interface(fn=CustomChatGPT, inputs = "text", outputs = "text", title = "Helio Chatbot", description = "Dedicated to provide seamless healthcare services to patients.")

demo.launch(share=True)